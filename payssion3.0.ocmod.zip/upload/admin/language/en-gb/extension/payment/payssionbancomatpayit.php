<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'BANCOMAT Pay (via Payssion)';
$_['text_payssionbancomatpayit']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/bancomatpay_it.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';