<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Pago Fácil (via Payssion)';
$_['text_payssionpagofacilar']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/pagofacil_ar.png" alt="Pago Efectivo" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';