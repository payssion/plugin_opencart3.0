<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Paysbuy Thailand (via Payssion)';
$_['text_payssionpaysbuyth']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/paysbuy_th.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';