<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Caixa Brazil (via Payssion)';
$_['text_payssioncaixa']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/caixa_br.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';