<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Naver Pay (via Payssion)';
$_['text_payssionnaverpaykr']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/naverpay_kr.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';