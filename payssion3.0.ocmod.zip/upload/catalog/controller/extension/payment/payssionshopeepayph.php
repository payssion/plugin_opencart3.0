<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionShoeepayph extends ControllerExtensionPaymentPayssion {
    protected $pm_id = 'shopeepay_ph';
}