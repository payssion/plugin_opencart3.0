<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionATMVAid extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'atmva_id';
}