<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionBanktransfertr extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'banktransfer_tr';
}