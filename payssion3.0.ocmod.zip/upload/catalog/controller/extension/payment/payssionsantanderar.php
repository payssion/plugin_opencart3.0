<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionSantanderar extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'santander_ar';
}