<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionTrustly extends ControllerExtensionPaymentPayssion {
    protected $pm_id = 'trustly';
}