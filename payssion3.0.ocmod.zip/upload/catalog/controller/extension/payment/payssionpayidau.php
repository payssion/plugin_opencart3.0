<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionPayidau extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'payid_au';
}