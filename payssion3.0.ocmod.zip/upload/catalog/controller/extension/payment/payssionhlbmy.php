<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionHLBmy extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'hlb_my';
}