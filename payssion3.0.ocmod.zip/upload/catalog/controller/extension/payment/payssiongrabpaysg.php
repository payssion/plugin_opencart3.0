<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionGrabpaysg extends ControllerExtensionPaymentPayssion {
    protected $pm_id = 'grabpay_sg';
}