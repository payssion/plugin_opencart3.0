<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionPicpaybr extends ControllerExtensionPaymentPayssion {
    protected $pm_id = 'picpay_br';
}