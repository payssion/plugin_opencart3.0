<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionPagofacilar extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'pagofacil_ar';
}